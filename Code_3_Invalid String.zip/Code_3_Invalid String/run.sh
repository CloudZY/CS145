# Execute in python 3
python ./code/twitter_crawler.py

# cat "sample_tweets.json" | while read line;
# do
# echo $line;
# done
There are two twitter crawler code:
1. twitter_api_sampe.py - use streaming 
2. twitter_crawler.py - use twitter search api
Both worked well with our feeding keywords.

In the run.sh, we only run the second crawler (twitter_crawler.py) as demo and it is run in python3.